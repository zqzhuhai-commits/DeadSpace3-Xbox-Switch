// ds3-nx - CPU hooks on the game's own functions (built into the game module: cmake/ds3_switch.cmake says why).
//
// SetThreadPriority (the XDK's Win32 one, 0x88BA72D0; Dead Space 2's EA::Thread::SetThreadPriority wrapper is inlined in
// Dead Space 3, which calls this directly): EA's job workers raise their priority to 127 before each job and drop it to
// -128 after it. In the SDK kernel each call is a handle lookup, a priority change and a release, every one under the
// object table's lock (the one every WaitForSingleObject and ReleaseSemaphore also takes), and with
// ignore_thread_priorities the host thread's priority does not change anyway. Then it only reports success. (Run 6
// stack samples: 8-10 % of each job worker's samples were in it.)
//
// Direct3D's GPU wait step (0x88A20950): BlockOnFence and the other Direct3D waits call it in a loop until the GPU (here
// the ring thread) has passed a fence. On the Xbox 360 its db16cyc delays cost one hardware thread of six; here they
// compile to nothing and the loop takes a whole core from the threads it waits for (the ring thread, the audio mixers,
// the job workers). Run 7's stack samples: 6 % of the main thread in calm play, 40-60 % while the ring thread was slow.
// While it answers "still waiting" the thread yields the first ds3_espera_gpu_cesiones times and then sleeps
// ds3_espera_gpu_us: a Horizon sleep often lasts far longer than asked, so short waits (most) do not pay for one.
// gears2-nx hooks the same function (gow2_perf_hooks.cpp).

#include "ds3_pch.h"

#include <chrono>

#include <rex/cvar.h>
#include <rex/thread.h>

#include "ds3_gpu.h"

REXCVAR_DECLARE(bool, ignore_thread_priorities);

REX_EXTERN(__imp__ds3_SetThreadPriority);
REX_EXTERN(ds3_SetThreadPriority) {
  if (REXCVAR_GET(ignore_thread_priorities)) {
    ctx.r3.u64 = 1;  // TRUE
    return;
  }
  __imp__ds3_SetThreadPriority(ctx, base);
}

REXCVAR_DECLARE(int32_t, ds3_espera_gpu_us);
REXCVAR_DECLARE(int32_t, ds3_espera_gpu_cesiones);

REX_EXTERN(__imp__ds3_D3D_GpuWaitStep);
REX_EXTERN(ds3_D3D_GpuWaitStep) {
  thread_local uint32_t seguidas = 0;  // "still waiting" answers in a row on this thread
  __imp__ds3_D3D_GpuWaitStep(ctx, base);
  if (ctx.r3.u32 != 1) {  // the GPU got there
    seguidas = 0;
    return;
  }
  const int32_t us = REXCVAR_GET(ds3_espera_gpu_us);
  if (us <= 0) return;
  if (++seguidas <= uint32_t(REXCVAR_GET(ds3_espera_gpu_cesiones))) {
    rex::thread::MaybeYield();
  } else {
    rex::thread::Sleep(std::chrono::microseconds(us));
  }
}

// D3DDevice_SetGammaRamp(device, flags, ramp): Direct3D corrects the game's ramp (GammaRampCorrected) and keeps it in
// the device at +15408 (1536 bytes) for the display output; Displ_SetGamma calls it with the in-game brightness. The
// Switch's output never saw it, so the brightness setting did nothing. After the original, the device's copy goes to
// the renderer (ds3_gpu.cpp, applied at the next present; nfsmw_nativo_rampa_gamma = false turns it off there).
REX_EXTERN(__imp__ds3_D3DDevice_SetGammaRamp);
REX_EXTERN(ds3_D3DDevice_SetGammaRamp) {
  const uint32_t dispositivo = ctx.r3.u32;
  __imp__ds3_D3DDevice_SetGammaRamp(ctx, base);
  ds3::gpu::PonerRampaGamma(REX_RAW_ADDR(dispositivo + 15408));
}

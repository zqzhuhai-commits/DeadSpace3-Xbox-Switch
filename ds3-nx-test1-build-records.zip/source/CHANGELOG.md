# Changelog

## 1.0.1

Stable and playable: 540p / 30 fps at stock clocks, 720p / 30 fps with a mild overclock.


- The in-game brightness setting works: D3DDevice_SetGammaRamp's corrected ramp (device +15408) goes to the renderer's
  output table at the next present (from ds2-nx 1.2.2).
- Vibration: `input_vibracion` defaults to true, so the game's own vibration setting decides (`ds3.toml` can still turn
  it off).
- RenderWare Audio: StreamPool::AcquireStream with no pool answers "no stream" instead of reading the pool's flags at
  +0x3C (the null-pool crash Dead Space 2 had after sleep and on some loads).
- Vibration strength: the game's values are for the Xbox 360 pad's motors, which the Switch's HD Rumble plays much
  harder. 50 % by default, and the options menu (ZL + ZR + Minus) has a VIBRATION row: Left / Right pick
  0 / 25 / 50 / 75 / 100 % (felt at once), A saves it to `ds3_vibracion.txt`. SDK patch 0032 (`input_vibracion_fuerza`,
  from ds2-nx).

## 1.0.0

First release (see the GitHub release notes).
